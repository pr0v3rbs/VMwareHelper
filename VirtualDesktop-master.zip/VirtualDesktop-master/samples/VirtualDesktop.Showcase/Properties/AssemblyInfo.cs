﻿using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows;

[assembly: AssemblyTitle("VirtualDesktop.Showcase")]
[assembly: AssemblyCompany("grabacr.net")]
[assembly: AssemblyProduct("VirtualDesktop")]
[assembly: AssemblyDescription("C# wrapper for IVirtualDesktopManager on Windows 10.")]
[assembly: AssemblyCopyright("Copyright © 2015 Manato KAMEYA")]

[assembly: ComVisible(false)]
[assembly: Guid("5B4544B8-3EF0-4E9F-8D60-DD605AD99725")]
[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]

[assembly: AssemblyVersion("1.0.0.0")]
