﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("VirtualDesktop.WinForms")]
[assembly: AssemblyCompany("grabacr.net")]
[assembly: AssemblyProduct("VirtualDesktop")]
[assembly: AssemblyDescription("C# wrapper for IVirtualDesktopManager on Windows 10.")]
[assembly: AssemblyCopyright("Copyright © 2015 Manato KAMEYA")]

[assembly: ComVisible(false)]
[assembly: Guid("da586cec-2ffe-42c5-aeda-56d25984c7ad")]

[assembly: AssemblyVersion("1.0.3")]
[assembly: AssemblyInformationalVersion("1.0.3")]
