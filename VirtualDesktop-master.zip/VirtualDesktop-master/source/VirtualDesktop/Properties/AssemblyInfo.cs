﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("VirtualDesktop")]
[assembly: AssemblyCompany("grabacr.net")]
[assembly: AssemblyProduct("VirtualDesktop")]
[assembly: AssemblyDescription("C# wrapper for IVirtualDesktopManager on Windows 10.")]
[assembly: AssemblyCopyright("Copyright © 2015 Manato KAMEYA")]

[assembly: ComVisible(false)]
[assembly: Guid("ab848ecd-76aa-41c0-b63d-86a8591b25aa")]

[assembly: AssemblyVersion("2.0.0")]
[assembly: AssemblyInformationalVersion("2.0.0-beta3")]
